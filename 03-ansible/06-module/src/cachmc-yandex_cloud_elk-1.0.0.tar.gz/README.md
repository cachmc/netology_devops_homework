# Collection for Ansible create ELK stack in Yandex Cloud

[![MIT licensed][badge-license]][link-license]

This collection was developed as part of the training. 

It contains a two modules: 
- create file

It contains a two modules:
- create file

## Installation

Before using, copy the repository and build the collection by running the command from the root directory of the project.
After build, install the collection from the archive.

Build:

```sh
ansible-galaxy collection build
```

Install:

```sh
ansible-galaxy collection install <archivename>.tar.gz
```

## Usage

Here's an example playbook which creation file:

```yaml
- hosts: localhost
  connection: local
  gather_facts: false

  collections:
    - cachmc.yandex_cloud_elk

  vars:
    create_file_path: /tmp/new_file.txt
    create_file_content: |
      Hello, world!

  roles:
    - role: create_file
```

## License

MIT

## Author

This collection was created by Vladislav Shishkov.

[badge-license]: https://img.shields.io/github/license/geerlingguy/ansible-collection-mac.svg
[link-license]: https://github.com/cachmc/ansible-collection-yandex_cloud_elk/blob/master/LICENSE
