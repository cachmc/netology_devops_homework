# Collection for Ansible create ELK stack in Yandex Cloud

[![MIT licensed][badge-license]][link-license]

This collection was developed as part of the training. 

It contains a two modules: 
- create compute instance in YC
- create file

It contains a two modules:
- settings LightHouse for ClickHouse
- settings Vector
- create file

## Installation

Before using, copy the repository and build the collection by running the command from the root directory of the project.
After build, install the collection from the archive.

Build:

```sh
ansible-galaxy collection build
```

Install:

```sh
ansible-galaxy collection install <archivename>.tar.gz
```

## Requirements

The module `compute_instance_create` requires python libraries to work: 
  - *grpcio*
  - *grpcio-tools*
  - *yandexcloud*

```sh
pip install grpcio grpcio-tools yandexcloud
```

## Usage

Here's an example playbook which creation compute instances:

```yaml
- hosts: localhost
  connection: local
  gather_facts: false

    - name: Create host
      cachmc.yandex_cloud_elk.compute_instance_create:
        iam_token: "t1.9euelZqNk8aSmJ7JmM-YmcvNypbNy-3rnpWamI3HkYvNi8aOxpbOkJubmMz....."
        folder_id: "nsbc7shmwkw938u3jd"
        name: "{{ hostname }}"
        resources:
          cores: 4
          memory: 4294967296
          disk:
            size: 21474836480
          network:
            subnet_id: "e9bgsjqoc62kshqr1vgk"
        ssh_user: "ubuntu"
        ssh_public_key: "ssh-ed25519 HSYUAINBHVADSBX7162etdghqaASDAnalI&TGQUasdDSJQ....."
      delegate_to: localhos      register: create_compute_instance

    - set_fact:
        ansible_host: "{{ create_compute_instance.external_ip_address }}"
        cacheable: yes
```

Here's an example playbook which setting Vector and LightHouse:

```yaml
### Vector ###
- hosts: vector

  collections:
    - cachmc.yandex_cloud_elk

  vars:
    vector_version: "0.42.0"
    vector_ch_address: "10.0.1.10"
    vector_ch_user: "vector"
    vector_ch_password: "vector"
    vector_ch_port: "8123"
    vector_ch_db_name: "logs"
    vector_ch_table_name: "random_log"
    vector_configs_add:
      clickhouse: "{{ lookup('template', './templates/clickhouse.yaml.j2') }}"

  roles:
    - role: vector

### LightHouse ###
- hosts: lighthouse

  vars:
    lighthouse_install_path: "/opt/lighthouse"
    lighthouse_ch_address: "10.0.1.10"
    lighthouse_ch_user: "lighthouse"
    lighthouse_ch_password: "lighthouse"
    lighthouse_ch_db: "logs"
    lighthouse_ch_table: "random_log"

  collections:
    - cachmc.yandex_cloud_elk

  roles:
    - role: lighthouse
```

Here's an example playbook which creation file:

```yaml
- hosts: test

  collections:
    - cachmc.yandex_cloud_elk

  vars:
    create_file_path: /tmp/new_file.txt
    create_file_content: |
      Hello, world!

  roles:
    - role: create_file
```

## License

MIT

## Author

This collection was created by Vladislav Shishkov.

[badge-license]: https://img.shields.io/github/license/geerlingguy/ansible-collection-mac.svg
[link-license]: https://github.com/cachmc/ansible-collection-yandex_cloud_elk/blob/master/LICENSE
